package com.claude.ai.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.claude.ai.ui.MainActivity

class AudioRecordService : Service() {
    companion object {
        const val CHANNEL_ID = "claude_audio_channel"
        const val NOTIFICATION_ID = 1001
    }

    private val binder = LocalBinder()
    inner class LocalBinder : Binder() { fun getService(): AudioRecordService = this@AudioRecordService }

    override fun onCreate() { super.onCreate(); createNotificationChannel() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification()); return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Claude AI")
            .setContentText("Режим аудио активен — микрофон включён")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent).setOngoing(true).setSilent(true).build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Claude Audio", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Claude AI audio recording service"; setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() { super.onDestroy(); stopForeground(STOP_FOREGROUND_REMOVE) }
}
