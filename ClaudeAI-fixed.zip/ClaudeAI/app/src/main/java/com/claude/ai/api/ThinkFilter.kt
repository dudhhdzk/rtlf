package com.claude.ai.api

/**
 * Потоковый фильтр «мыслей». Вырезает блоки <think>...</think> (и <reasoning>...)
 * даже когда теги приходят по частям в разных SSE-чанках.
 */
class ThinkFilter {
    private val open = listOf("<think>", "<reasoning>")
    private val close = listOf("</think>", "</reasoning>")
    private var inThink = false
    private val buffer = StringBuilder()

    fun push(chunk: String): String {
        buffer.append(chunk)
        val out = StringBuilder()
        loop@ while (true) {
            if (!inThink) {
                val idx = firstIndexOfAny(buffer, open)
                if (idx == null) {
                    val safe = buffer.length - maxPartialSuffix(buffer, open)
                    if (safe > 0) { out.append(buffer.substring(0, safe)); buffer.delete(0, safe) }
                    break@loop
                } else {
                    out.append(buffer.substring(0, idx))
                    val tag = open.first { buffer.startsWith(it, idx) }
                    buffer.delete(0, idx + tag.length)
                    inThink = true
                }
            } else {
                val idx = firstIndexOfAny(buffer, close)
                if (idx == null) {
                    val keep = maxPartialSuffix(buffer, close)
                    buffer.delete(0, buffer.length - keep)
                    break@loop
                } else {
                    val tag = close.first { buffer.startsWith(it, idx) }
                    buffer.delete(0, idx + tag.length)
                    inThink = false
                }
            }
        }
        return out.toString()
    }

    fun flush(): String {
        if (inThink) { buffer.setLength(0); return "" }
        val rest = buffer.toString(); buffer.setLength(0); return rest
    }

    private fun firstIndexOfAny(sb: StringBuilder, tags: List<String>): Int? {
        var best = -1
        for (t in tags) {
            val i = sb.indexOf(t)
            if (i >= 0 && (best == -1 || i < best)) best = i
        }
        return if (best == -1) null else best
    }

    private fun maxPartialSuffix(sb: StringBuilder, tags: List<String>): Int {
        var max = 0
        for (t in tags) {
            var k = minOf(t.length - 1, sb.length)
            while (k > 0) {
                if (sb.substring(sb.length - k) == t.substring(0, k)) { if (k > max) max = k; break }
                k--
            }
        }
        return max
    }
}
