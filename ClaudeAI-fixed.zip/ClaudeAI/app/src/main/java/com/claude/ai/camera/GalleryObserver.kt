package com.claude.ai.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class GalleryObserver(
    private val context: Context,
    private val onNewPhoto: (Bitmap, Uri) -> Unit,
    private val onError: (String) -> Unit = {}
) {
    private var contentObserver: ContentObserver? = null
    private var lastKnownUri: Uri? = null
    private val handler = Handler(Looper.getMainLooper())
    private var scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private fun hasGalleryPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun startObserving() {
        if (!hasGalleryPermission()) { onError("Нет разрешения на галерею"); return }
        if (contentObserver != null) return
        if (!scope.isActive) scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        lastKnownUri = getLatestImageUri()
        contentObserver = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                if (!scope.isActive) return
                scope.launch { delay(500); checkForNewPhoto() }
            }
        }
        try {
            context.contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, contentObserver!!)
        } catch (e: Exception) { onError("Не удалось запустить слежение: ${e.message}") }
    }

    fun stopObserving() {
        contentObserver?.let {
            try { context.contentResolver.unregisterContentObserver(it) } catch (e: Exception) { }
            contentObserver = null
        }
        scope.cancel()
    }

    private fun getLatestImageUri(): Uri? {
        if (!hasGalleryPermission()) return null
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED)
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
        return try {
            context.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, sortOrder)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                } else null
            }
        } catch (e: SecurityException) { handler.post { onError("Нет разрешения на галерею") }; null }
        catch (e: Exception) { null }
    }

    private fun checkForNewPhoto() {
        val latestUri = getLatestImageUri() ?: return
        if (latestUri != lastKnownUri) {
            lastKnownUri = latestUri
            val bitmap = loadBitmapFromUri(latestUri)
            if (bitmap != null) handler.post { onNewPhoto(bitmap, latestUri) }
        }
    }

    fun getLatestPhoto(): Bitmap? { val uri = getLatestImageUri() ?: return null; return loadBitmapFromUri(uri) }
    fun getLatestPhotoUri(): Uri? = getLatestImageUri()

    private fun loadBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            context.contentResolver.openInputStream(uri)?.use {
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(it, null, options)
                options.inSampleSize = calculateInSampleSize(options, 1024, 1024)
                options.inJustDecodeBounds = false
                context.contentResolver.openInputStream(uri)?.use { s -> BitmapFactory.decodeStream(s, null, options) }
            }
        } catch (e: Exception) { null }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height, width) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2; val halfWidth = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) inSampleSize *= 2
        }
        return inSampleSize
    }
}
