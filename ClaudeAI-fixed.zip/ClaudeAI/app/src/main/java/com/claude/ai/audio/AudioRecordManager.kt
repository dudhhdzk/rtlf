package com.claude.ai.audio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class RecordingState { IDLE, LISTENING, PROCESSING }

/** Классическое системное распознавание (кнопка микрофона). Шёпот — в WhisperAudioManager. */
class AudioRecordManager(private val context: Context) {

    companion object {
        private const val TAG = "AudioRecordManager"
        private const val MAX_LISTEN_MS = 10_000L
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var speechRecognizer: SpeechRecognizer? = null
    private var autoStopJob: Job? = null

    private val _recordingState = MutableStateFlow(RecordingState.IDLE)
    val recordingState: StateFlow<RecordingState> = _recordingState

    private val _transcribedText = MutableStateFlow("")
    val transcribedText: StateFlow<String> = _transcribedText

    private var onResultCallback: ((String) -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null
    private var recognitionAvailable = false

    private var continuous = false
    private var currentLanguage = "ru-RU"

    fun initialize() {
        recognitionAvailable = SpeechRecognizer.isRecognitionAvailable(context)
        if (recognitionAvailable) setupSpeechRecognizer()
        else Log.w(TAG, "Speech recognition not available on this device")
    }

    fun isAvailable(): Boolean = recognitionAvailable
    fun isContinuous(): Boolean = continuous

    private fun setupSpeechRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { _recordingState.value = RecordingState.LISTENING }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { _recordingState.value = RecordingState.PROCESSING }
                override fun onError(error: Int) {
                    cancelAutoStop()
                    _recordingState.value = RecordingState.IDLE
                    val msg = getSpeechErrorMessage(error)
                    Log.e(TAG, "Speech error: $msg ($error)")
                    val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    if (continuous) restartSoon() else if (!quiet) onErrorCallback?.invoke(msg)
                }
                override fun onResults(results: Bundle?) {
                    cancelAutoStop()
                    _recordingState.value = RecordingState.IDLE
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (text.isNotBlank()) {
                        _transcribedText.value = text
                        onResultCallback?.invoke(text)
                    }
                    if (continuous) restartSoon()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (text.isNotBlank()) _transcribedText.value = text
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun buildIntent(language: String): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }

    fun startListening(language: String = "ru-RU", onResult: (String) -> Unit, onError: (String) -> Unit) {
        onResultCallback = onResult
        onErrorCallback = onError
        currentLanguage = language
        if (!recognitionAvailable) {
            onError("Распознавание речи недоступно (нет Google App). Включите режим шёпота или вводите текстом.")
            return
        }
        if (_recordingState.value != RecordingState.IDLE) { stopListening(); setupSpeechRecognizer() }
        speechRecognizer?.startListening(buildIntent(language))
        _recordingState.value = RecordingState.LISTENING
        scheduleAutoStop()
    }

    fun startContinuous(language: String = "ru-RU", onResult: (String) -> Unit, onError: (String) -> Unit) {
        continuous = true
        startListening(language, onResult, onError)
    }

    fun stopContinuous() { continuous = false; stopListening() }

    private fun restartSoon() {
        if (!continuous) return
        scope.launch {
            delay(350)
            if (continuous) {
                setupSpeechRecognizer()
                speechRecognizer?.startListening(buildIntent(currentLanguage))
                _recordingState.value = RecordingState.LISTENING
                scheduleAutoStop()
            }
        }
    }

    private fun scheduleAutoStop() {
        cancelAutoStop()
        autoStopJob = scope.launch {
            delay(MAX_LISTEN_MS)
            if (_recordingState.value == RecordingState.LISTENING) speechRecognizer?.stopListening()
        }
    }
    private fun cancelAutoStop() { autoStopJob?.cancel(); autoStopJob = null }

    fun stopListening() {
        cancelAutoStop()
        speechRecognizer?.stopListening()
        _recordingState.value = RecordingState.IDLE
    }

    fun isListening(): Boolean = _recordingState.value == RecordingState.LISTENING

    fun destroy() {
        continuous = false
        cancelAutoStop()
        speechRecognizer?.destroy()
        speechRecognizer = null
        scope.cancel()
    }

    private fun getSpeechErrorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Ошибка аудио"
        SpeechRecognizer.ERROR_CLIENT -> "Ошибка клиента"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет разрешения на микрофон"
        SpeechRecognizer.ERROR_NETWORK -> "Ошибка сети"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Таймаут сети"
        SpeechRecognizer.ERROR_NO_MATCH -> "Речь не распознана"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Распознаватель занят"
        SpeechRecognizer.ERROR_SERVER -> "Ошибка сервера"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Нет речи"
        else -> "Неизвестная ошибка ($error)"
    }
}
