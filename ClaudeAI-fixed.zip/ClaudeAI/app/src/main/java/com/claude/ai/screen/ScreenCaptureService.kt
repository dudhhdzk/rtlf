package com.claude.ai.screen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * Foreground-сервис mediaProjection. Умеет ждать заданную задержку перед снимком —
 * успеваешь свернуть приложение и открыть то, что реально надо показать ИИ.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "claude_screencap_channel"
        const val NOTIFICATION_ID = 1002
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        const val EXTRA_DELAY_MS = "delay_ms"

        @Volatile var onFrame: ((Bitmap?) -> Unit)? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val delayMs = intent?.getLongExtra(EXTRA_DELAY_MS, 0L) ?: 0L
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)

        if (resultCode == 0 || data == null) { deliver(null); stopSelf(); return START_NOT_STICKY }

        // Задержка: время переключиться в нужное приложение.
        handler.postDelayed({ doCapture(resultCode, data) }, delayMs)
        return START_NOT_STICKY
    }

    private fun doCapture(resultCode: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection: MediaProjection? = mpm.getMediaProjection(resultCode, data)
        if (projection == null) { deliver(null); stopSelf(); return }
        projection.registerCallback(object : MediaProjection.Callback() {}, null)
        ScreenCaptureManager(this).capture(projection) { bmp ->
            deliver(bmp)
            stopSelf()
        }
    }

    private fun deliver(bmp: Bitmap?) { val cb = onFrame; onFrame = null; cb?.invoke(bmp) }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Screen capture", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Claude AI")
            .setContentText("Демонстрация экрана")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setSilent(true).build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, n)
    }
}
