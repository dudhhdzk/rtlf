package com.claude.ai.screen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/** Делает один снимок экрана через MediaProjection. */
class ScreenCaptureManager(private val context: Context) {
    companion object { private const val TAG = "ScreenCapture" }

    private val handler = Handler(Looper.getMainLooper())

    fun capture(projection: MediaProjection, onResult: (Bitmap?) -> Unit) {
        try {
            val metrics = DisplayMetrics()
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            var virtualDisplay: VirtualDisplay? = null
            var done = false

            fun finish(bmp: Bitmap?) {
                if (done) return
                done = true
                try { virtualDisplay?.release() } catch (e: Exception) { }
                try { imageReader.close() } catch (e: Exception) { }
                try { projection.stop() } catch (e: Exception) { }
                handler.post { onResult(bmp) }
            }

            virtualDisplay = projection.createVirtualDisplay(
                "claude-screencap", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface, null, handler
            )

            imageReader.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    var bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    bitmap.copyPixelsFromBuffer(buffer)
                    if (rowPadding != 0) bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                    finish(bitmap)
                } catch (e: Exception) {
                    Log.e(TAG, "capture decode error", e); finish(null)
                } finally { image.close() }
            }, handler)

            handler.postDelayed({ if (!done) finish(null) }, 4000)
        } catch (e: Exception) {
            Log.e(TAG, "capture error", e); onResult(null)
        }
    }
}
