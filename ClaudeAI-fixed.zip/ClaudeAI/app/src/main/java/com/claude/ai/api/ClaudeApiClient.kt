package com.claude.ai.api

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

data class Message(
    val role: String,
    val content: String,
    val imageBitmap: Bitmap? = null
)

data class StreamChunk(
    val text: String,
    val isComplete: Boolean,
    val error: String? = null
)

enum class ApiProvider(
    val displayName: String,
    val prefsKey: String,
    val keyHint: String,
    val baseUrl: String,
    val textModels: List<String>,
    val visionModels: List<String>
) {
    GROQ(
        "Groq", "groq_api_key", "gsk_...",
        "https://api.groq.com/openai/v1/chat/completions",
        listOf("openai/gpt-oss-120b", "openai/gpt-oss-20b", "llama-3.3-70b-versatile"),
        listOf("qwen/qwen3.6-27b", "meta-llama/llama-4-scout-17b-16e-instruct")
    ),
    GLM(
        "GLM (Z.ai)", "glm_api_key", "GLM API key",
        "https://api.z.ai/api/paas/v4/chat/completions",
        listOf("glm-5.2", "glm-4-plus", "glm-4-flash"),
        listOf("glm-5v-turbo", "glm-4v-plus")
    );

    companion object {
        fun fromName(name: String?): ApiProvider = entries.firstOrNull { it.name == name } ?: GROQ
    }
}

class ClaudeApiClient(private val context: Context) {

    companion object {
        private const val TAG = "AiApiClient"
        private const val MAX_TOKENS = 2048
        private const val MAX_IMAGE_SIZE = 768
        const val MAX_KEYS = 3
        private const val WHISPER_URL = "https://api.groq.com/openai/v1/audio/transcriptions"

        /** Системная добавка: запрещаем модели сыпать разметкой — её потом озвучивает TTS. */
        const val CLEAN_SPEECH_RULES =
            "\n\nВАЖНО: твой ответ будет озвучен голосом. Пиши только обычным текстом. " +
            "Никакой разметки: без звёздочек, решёток, markdown, таблиц, эмодзи, кода и списков со значками. " +
            "Не повторяй одно и то же слово дважды подряд. Не пиши служебных пояснений о себе."
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val prefs = context.getSharedPreferences("claude_prefs", Context.MODE_PRIVATE)

    // ---------- Провайдер ----------
    fun getProvider(): ApiProvider = ApiProvider.fromName(prefs.getString("api_provider", ApiProvider.GROQ.name))
    fun setProvider(provider: ApiProvider) = prefs.edit().putString("api_provider", provider.name).apply()

    // ---------- Модели ----------
    fun getTextModel(provider: ApiProvider = getProvider()): String =
        prefs.getString("${provider.prefsKey}_text_model", null) ?: provider.textModels.first()
    fun setTextModel(provider: ApiProvider, model: String) =
        prefs.edit().putString("${provider.prefsKey}_text_model", model).apply()

    fun getVisionModel(provider: ApiProvider = getProvider()): String =
        prefs.getString("${provider.prefsKey}_vision_model", null) ?: provider.visionModels.first()
    fun setVisionModel(provider: ApiProvider, model: String) =
        prefs.edit().putString("${provider.prefsKey}_vision_model", model).apply()

    // ---------- Ключи ----------
    private fun keyPref(provider: ApiProvider, index: Int): String =
        if (index == 0) provider.prefsKey else "${provider.prefsKey}_${index + 1}"

    fun getApiKey(): String = getApiKey(getProvider())
    fun getApiKey(provider: ApiProvider): String = getApiKey(provider, 0)
    fun getApiKey(provider: ApiProvider, index: Int): String = prefs.getString(keyPref(provider, index), "") ?: ""

    fun setApiKey(key: String) = setApiKey(getProvider(), 0, key)
    fun setApiKey(provider: ApiProvider, key: String) = setApiKey(provider, 0, key)
    fun setApiKey(provider: ApiProvider, index: Int, key: String) =
        prefs.edit().putString(keyPref(provider, index), key).apply()

    fun getApiKeys(provider: ApiProvider = getProvider()): List<String> =
        (0 until MAX_KEYS).map { getApiKey(provider, it) }.filter { it.isNotBlank() }

    fun getSystemPrompt(): String = prefs.getString("system_prompt",
        "Ты полезный ИИ-ассистент. Отвечай кратко и по делу. Не показывай ход рассуждений, давай сразу ответ.") ?: ""
    fun setSystemPrompt(prompt: String) = prefs.edit().putString("system_prompt", prompt).apply()

    fun getAutoPhotoPrompt(): String = prefs.getString("auto_photo_prompt",
        "Что изображено на этом фото? Опиши подробно.") ?: ""
    fun setAutoPhotoPrompt(prompt: String) = prefs.edit().putString("auto_photo_prompt", prompt).apply()

    private fun bitmapToBase64(bitmap: Bitmap): String {
        return try {
            val outputStream = ByteArrayOutputStream()
            val scaled = if (bitmap.width > MAX_IMAGE_SIZE || bitmap.height > MAX_IMAGE_SIZE) {
                val scale = minOf(
                    MAX_IMAGE_SIZE.toFloat() / bitmap.width,
                    MAX_IMAGE_SIZE.toFloat() / bitmap.height
                )
                Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true)
            } else bitmap
            scaled.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            Log.e(TAG, "Error converting bitmap to base64", e)
            ""
        }
    }

    private fun buildRequestBody(
        messages: List<Message>, systemPrompt: String, useVision: Boolean, provider: ApiProvider
    ): JSONObject {
        val messagesArray = JSONArray()
        messagesArray.put(JSONObject().apply {
            put("role", "system"); put("content", systemPrompt + CLEAN_SPEECH_RULES)
        })
        for (msg in messages) {
            val role = if (msg.role == "user") "user" else "assistant"
            if (msg.imageBitmap != null && useVision) {
                val base64 = bitmapToBase64(msg.imageBitmap)
                if (base64.isNotEmpty()) {
                    val contentArray = JSONArray()
                    if (msg.content.isNotBlank()) {
                        contentArray.put(JSONObject().apply { put("type", "text"); put("text", msg.content) })
                    }
                    contentArray.put(JSONObject().apply {
                        put("type", "image_url")
                        put("image_url", JSONObject().apply { put("url", "data:image/jpeg;base64,$base64") })
                    })
                    messagesArray.put(JSONObject().apply { put("role", role); put("content", contentArray) })
                } else {
                    messagesArray.put(JSONObject().apply { put("role", role); put("content", msg.content.ifBlank { "Опиши фото" }) })
                }
            } else {
                messagesArray.put(JSONObject().apply { put("role", role); put("content", msg.content) })
            }
        }
        val model = if (useVision) getVisionModel(provider) else getTextModel(provider)
        return JSONObject().apply {
            put("model", model)
            put("max_tokens", MAX_TOKENS)
            put("messages", messagesArray)
            put("stream", true)
            put("temperature", 0.7)
        }
    }

    private fun isRetriableCode(code: Int): Boolean =
        code == 401 || code == 403 || code == 429 || code in 500..599

    fun sendMessageStream(
        messages: List<Message>,
        systemPrompt: String = getSystemPrompt()
    ): Flow<StreamChunk> = flow {
        val provider = getProvider()
        val keys = getApiKeys(provider)
        if (keys.isEmpty()) {
            emit(StreamChunk("", false, "Ключ ${provider.displayName} не установлен. Настройки — API ключ."))
            return@flow
        }

        val hasImage = messages.any { it.imageBitmap != null }
        val requestBody = buildRequestBody(messages, systemPrompt, hasImage, provider)
        var lastError = ""

        for ((idx, key) in keys.withIndex()) {
            val request = Request.Builder()
                .url(provider.baseUrl)
                .addHeader("Authorization", "Bearer $key")
                .addHeader("Content-Type", "application/json")
                .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = try {
                withContext(Dispatchers.IO) { httpClient.newCall(request).execute() }
            } catch (e: IOException) {
                lastError = "сеть: ${e.message}"
                Log.w(TAG, "[key #${idx + 1}] network fail, trying next", e)
                continue
            }

            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "Unknown error"
                val errorMsg = try {
                    JSONObject(errorBody).optJSONObject("error")?.optString("message") ?: errorBody
                } catch (e: Exception) { errorBody }
                lastError = "${response.code}: $errorMsg"
                Log.e(TAG, "[${provider.displayName} key #${idx + 1}] $lastError")
                if (isRetriableCode(response.code) && idx < keys.lastIndex) continue
                val hint = if (response.code == 404) " (модель могла устареть — смените модель в Настройках)" else ""
                emit(StreamChunk("", false, "Ошибка ${provider.displayName} $lastError$hint"))
                return@flow
            }

            val source = response.body?.source()
            if (source == null) {
                lastError = "пустой ответ"
                if (idx < keys.lastIndex) continue
                emit(StreamChunk("", false, "Ошибка ${provider.displayName}: $lastError"))
                return@flow
            }

            val think = ThinkFilter()
            while (!source.exhausted()) {
                val line = withContext(Dispatchers.IO) { source.readUtf8Line() } ?: break
                if (!line.startsWith("data: ")) continue
                val data = line.removePrefix("data: ").trim()
                if (data == "[DONE]") { emit(StreamChunk(think.flush(), false)); emit(StreamChunk("", true)); return@flow }
                if (data.isBlank()) continue
                try {
                    val json = JSONObject(data)
                    val choices = json.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val choice = choices.getJSONObject(0)
                        val delta = choice.optJSONObject("delta")
                        val text = delta?.optString("content", "") ?: ""
                        if (text.isNotEmpty()) {
                            val clean = think.push(text)
                            if (clean.isNotEmpty()) emit(StreamChunk(clean, false))
                        }
                        val finishReason = choice.optString("finish_reason", "")
                        if (finishReason == "stop" || finishReason == "length") {
                            emit(StreamChunk(think.flush(), false)); emit(StreamChunk("", true)); return@flow
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to parse SSE: $data", e)
                }
            }
            emit(StreamChunk(think.flush(), false))
            emit(StreamChunk("", true))
            return@flow
        }

        emit(StreamChunk("", false, "Все ключи ${provider.displayName} не сработали ($lastError)"))
    }.flowOn(Dispatchers.IO)

    /**
     * Транскрибация речи через Groq Whisper — ловит шёпот куда лучше системного распознавания.
     * Нужен ключ Groq (даже если основной провайдер GLM).
     */
    suspend fun transcribe(wav: ByteArray, language: String = "ru"): String = withContext(Dispatchers.IO) {
        val key = getApiKeys(ApiProvider.GROQ).firstOrNull()
        if (key.isNullOrBlank()) return@withContext "__NO_GROQ_KEY__"
        try {
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("model", "whisper-large-v3-turbo")
                .addFormDataPart("language", language)
                .addFormDataPart("temperature", "0")
                .addFormDataPart("response_format", "text")
                .addFormDataPart("file", "audio.wav", wav.toRequestBody("audio/wav".toMediaType()))
                .build()
            val request = Request.Builder()
                .url(WHISPER_URL)
                .addHeader("Authorization", "Bearer $key")
                .post(body).build()
            val resp = httpClient.newCall(request).execute()
            val text = resp.body?.string()?.trim() ?: ""
            if (!resp.isSuccessful) { Log.e(TAG, "Whisper ${resp.code}: $text"); return@withContext "" }
            text
        } catch (e: Exception) { Log.e(TAG, "transcribe error", e); "" }
    }

    suspend fun validateApiKey(key: String): Boolean = validateApiKey(getProvider(), key)
    suspend fun validateApiKey(provider: ApiProvider, key: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("model", getTextModel(provider))
                put("max_tokens", 10)
                put("messages", JSONArray().put(JSONObject().apply { put("role", "user"); put("content", "Hi") }))
            }
            val request = Request.Builder()
                .url(provider.baseUrl)
                .addHeader("Authorization", "Bearer $key")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val response = httpClient.newCall(request).execute()
            val ok = response.code in 200..299
            if (!ok) Log.e(TAG, "[${provider.displayName}] validate failed ${response.code}: ${response.body?.string()}")
            ok
        } catch (e: Exception) {
            Log.e(TAG, "validateApiKey error", e); false
        }
    }
}
