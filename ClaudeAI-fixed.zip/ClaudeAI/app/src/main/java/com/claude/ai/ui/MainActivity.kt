package com.claude.ai.ui

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.claude.ai.api.ApiProvider
import com.claude.ai.api.ClaudeApiClient
import com.claude.ai.audio.RecordingState
import com.claude.ai.databinding.ActivityMainBinding
import com.claude.ai.screen.ScreenCaptureService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var chatAdapter: ChatAdapter

    private var pendingScreenPrompt: String = ""
    private var pendingScreenDelayMs: Long = 0L

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (!results.values.all { it }) {
            Toast.makeText(this, "Некоторые разрешения отклонены. Часть функций может не работать.", Toast.LENGTH_LONG).show()
        }
    }

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? -> uri?.let { loadImageFromUri(it) } }

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            ScreenCaptureService.onFrame = { bmp -> runOnUiThread { viewModel.onScreenCaptured(pendingScreenPrompt, bmp) } }
            val svc = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_DELAY_MS, pendingScreenDelayMs)
            }
            ContextCompat.startForegroundService(this, svc)
            if (pendingScreenDelayMs > 0) {
                toast("Снимок через ${pendingScreenDelayMs / 1000} сек — открывай нужное приложение")
                moveTaskToBack(true) // сворачиваемся, чтобы снять НЕ своё приложение
            }
        } else {
            Toast.makeText(this, "Захват экрана отменён", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestPermissions()
        setupRecyclerView()
        setupUI()
        observeState()
        observeEvents()
        observeScreenCapture()
        observeTranscript()

        if (viewModel.getApiKey().isBlank()) showApiKeyDialog()
    }

    private fun requestPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        val notGranted = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (notGranted.isNotEmpty()) permissionLauncher.launch(notGranted.toTypedArray())
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter()
        binding.rvMessages.apply {
            adapter = chatAdapter
            layoutManager = LinearLayoutManager(this@MainActivity).apply { stackFromEnd = true }
        }
    }

    private fun setupUI() {
        binding.btnSend.setOnClickListener {
            val text = binding.etInput.text.toString().trim()
            viewModel.sendMessage(text)
            binding.etInput.setText("")
        }
        binding.btnMic.setOnClickListener {
            if (viewModel.uiState.value.recordingState == RecordingState.IDLE) viewModel.startVoiceInput()
            else viewModel.stopVoiceInput()
        }
        binding.btnAttach.setOnClickListener { imagePickerLauncher.launch("image/*") }
        binding.btnLatestPhoto.setOnClickListener { viewModel.attachLatestPhoto() }
        binding.btnRemoveImage.setOnClickListener { viewModel.setPendingImage(null) }

        binding.switchGallery.setOnCheckedChangeListener { _, checked ->
            if (checked != viewModel.uiState.value.galleryWatchEnabled) {
                viewModel.setGalleryWatch(checked)
                toast(if (checked) "Слежение за галереей включено" else "Выключено")
            }
        }
        binding.switchAutoMode.setOnCheckedChangeListener { _, checked ->
            if (checked != viewModel.uiState.value.autoPhotoMode) {
                viewModel.setAutoPhotoMode(checked)
                toast(if (checked) "Авто: фото + микрофон (микрофон включён сам)" else "Авто-режим выключен")
            }
        }
        binding.switchTts.setOnCheckedChangeListener { _, checked -> viewModel.setTtsEnabled(checked) }
        binding.switchAlwaysListen.setOnCheckedChangeListener { _, checked ->
            if (checked != viewModel.uiState.value.alwaysListen) {
                viewModel.setAlwaysListen(checked)
                toast(if (checked) "Режим шёпота: слышу даже тихий голос, текст падает в поле ввода" else "Выключено")
            }
        }
        binding.switchEcho.setOnCheckedChangeListener { _, checked ->
            if (checked != viewModel.uiState.value.echoMode) {
                viewModel.setEchoMode(checked)
                toast(if (checked) "Режим повтора" else "Выключен")
            }
        }

        // ТОЛЬКО глушит озвучку. Ничего не отправляет.
        binding.btnStopTts.setOnClickListener { viewModel.toggleSpeechMute() }
        binding.btnVoiceSelect.setOnClickListener { showVoiceSelectionDialog() }

        binding.sliderSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val speed = 0.5f + progress * 0.05f
                    viewModel.setSpeechRate(speed)
                    binding.tvSpeed.text = "%.1fx".format(speed)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        binding.btnClear.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Очистить чат?")
                .setPositiveButton("Да") { _, _ -> viewModel.clearConversation() }
                .setNegativeButton("Отмена", null).show()
        }
        binding.btnSettings.setOnClickListener { showSettingsMenu() }
        binding.btnRayBan.setOnClickListener { showRayBanDialog() }

        binding.btnBluetooth.setOnClickListener { onBluetoothButton() }
        binding.btnScreenShare.setOnClickListener { onScreenShareButton() }
        binding.btnShareApp.setOnClickListener { shareApp() }
        binding.btnHistory.setOnClickListener { showHistoryDialog() }
    }

    // ---------- Bluetooth ----------
    private fun onBluetoothButton() {
        val st = viewModel.uiState.value
        if (st.ttsBlocked) {
            AlertDialog.Builder(this)
                .setTitle("Bluetooth отключён")
                .setMessage("Связь оборвалась, озвучка остановлена мгновенно. Возобновить?")
                .setPositiveButton("Возобновить") { _, _ -> viewModel.unblockTts() }
                .setNegativeButton("Отмена", null).show()
            return
        }
        val items = arrayOf(
            if (st.bluetoothMode) "Выключить контроль звука BT" else "Включить контроль звука BT",
            "Общий диалог: стать хостом",
            "Общий диалог: подключиться к другу",
            "Отключить общий диалог"
        )
        AlertDialog.Builder(this).setTitle("Bluetooth")
            .setItems(items) { _, w ->
                when (w) {
                    0 -> {
                        val enable = !st.bluetoothMode
                        viewModel.setBluetoothMode(enable)
                        toast(if (enable) "Контроль звука BT включён" else "Выключен")
                    }
                    1 -> { viewModel.btHost(); toast("Ждём друга. Пусть он выберет тебя в списке.") }
                    2 -> showBtJoinDialog()
                    3 -> { viewModel.btStopChat(); toast("Общий диалог отключён") }
                }
            }.setNegativeButton("Закрыть", null).show()
    }

    private fun showBtJoinDialog() {
        val devices = viewModel.btBondedDevices()
        if (devices.isEmpty()) {
            toast("Нет сопряжённых устройств. Сначала спарьте телефоны в настройках Bluetooth.")
            return
        }
        val names = devices.map {
            try { it.name ?: it.address } catch (e: SecurityException) { it.address }
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Выберите друга")
            .setItems(names) { _, w -> viewModel.btJoin(devices[w]); toast("Подключаюсь к ${names[w]}") }
            .setNegativeButton("Отмена", null).show()
    }

    // ---------- Демонстрация экрана ----------
    private fun onScreenShareButton() {
        val enabling = !viewModel.uiState.value.screenShareMode
        viewModel.setScreenShareMode(enabling)
        if (enabling) {
            val delay = viewModel.uiState.value.screenShareDelaySec
            AlertDialog.Builder(this)
                .setTitle("Демонстрация экрана")
                .setMessage("Режим включён. Задержка перед снимком: $delay сек — успеешь открыть другое приложение. Изменить можно в Настройках.")
                .setPositiveButton("Снять сейчас") { _, _ -> viewModel.captureScreenNow() }
                .setNeutralButton("Задержка") { _, _ -> showScreenDelayDialog() }
                .setNegativeButton("OK", null).show()
        } else toast("Демонстрация экрана выключена")
    }

    private fun showScreenDelayDialog() {
        val current = viewModel.uiState.value.screenShareDelaySec
        val label = TextView(this).apply { text = "Задержка: $current сек"; setPadding(48, 32, 48, 8) }
        val seek = SeekBar(this).apply { max = 20; progress = current; setPadding(48, 8, 48, 32) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { label.text = "Задержка: $p сек" }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(label); addView(seek) }
        AlertDialog.Builder(this).setTitle("Время до снимка экрана").setView(box)
            .setPositiveButton("Сохранить") { _, _ -> viewModel.setScreenShareDelay(seek.progress); toast("Задержка: ${seek.progress} сек") }
            .setNegativeButton("Отмена", null).show()
    }

    private fun observeScreenCapture() {
        lifecycleScope.launch {
            viewModel.screenCaptureRequests.collectLatest { req ->
                pendingScreenPrompt = req.prompt
                pendingScreenDelayMs = req.delayMs
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }
    }

    /** Распознанный шёпот кладём в поле ввода — ничего не отправляется само. */
    private fun observeTranscript() {
        lifecycleScope.launch {
            viewModel.transcriptToInput.collectLatest { text ->
                val cur = binding.etInput.text.toString()
                val merged = if (cur.isBlank()) text else "$cur $text"
                binding.etInput.setText(merged)
                binding.etInput.setSelection(merged.length)
            }
        }
    }

    // ---------- Ray-Ban Meta ----------
    private fun showRayBanDialog() {
        val metaPackages = listOf(
            "com.facebook.stella",       // Meta View / Meta AI (очки)
            "com.facebook.miglasses",
            "com.facebook.katana"        // Facebook: живая трансляция
        )
        val installed = metaPackages.firstOrNull { pkgInstalled(it) }
        val msg = if (installed != null)
            "Приложение Meta найдено. Официального SDK трансляции с очков у Meta НЕТ, поэтому открываем родное приложение: там запускаешь трансляцию/съёмку, а снимки попадают в галерею — их подхватит режим «Авто (фото + микро)»."
        else
            "Приложение Meta не установлено. Публичного SDK трансляции с Ray-Ban Meta не существует, сторонние приложения к видеопотоку очков доступа не имеют. Рабочая схема: Meta AI (Meta View) — очки по Bluetooth — снимок с очков — он падает в галерею — режим «Авто (фото + микро)» отправляет его ИИ."

        val b = AlertDialog.Builder(this).setTitle("Ray-Ban Meta").setMessage(msg)
        if (installed != null) {
            b.setPositiveButton("Открыть Meta") { _, _ ->
                packageManager.getLaunchIntentForPackage(installed)?.let { startActivity(it) }
            }
            b.setNeutralButton("Включить авто-режим") { _, _ ->
                viewModel.setAutoPhotoMode(true); toast("Авто-режим включён")
            }
        } else {
            b.setPositiveButton("Включить авто-режим") { _, _ ->
                viewModel.setAutoPhotoMode(true); toast("Авто-режим включён")
            }
        }
        b.setNegativeButton("Закрыть", null).show()
    }

    private fun pkgInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) { false }

    // ---------- Поделиться ----------
    private fun shareApp() {
        try {
            val apk = File(applicationInfo.sourceDir)
            val dest = File(cacheDir, "ClaudeAI.apk")
            apk.copyTo(dest, overwrite = true)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Claude AI")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Поделиться приложением"))
        } catch (e: Exception) {
            toast("Не удалось поделиться: ${e.message}")
        }
    }

    private fun shareText(text: String) {
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
        startActivity(Intent.createChooser(intent, "Поделиться диалогом"))
    }

    private fun showHistoryDialog() {
        val convos = viewModel.listConversations()
        val actions = arrayOf("Сохранить текущий диалог") + convos.map { it.title }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Сохранённые диалоги")
            .setItems(actions) { _, which ->
                if (which == 0) viewModel.saveCurrentConversation()
                else {
                    val c = convos[which - 1]
                    AlertDialog.Builder(this)
                        .setTitle(c.title)
                        .setItems(arrayOf("Открыть", "Поделиться", "Удалить")) { _, act ->
                            when (act) {
                                0 -> viewModel.loadConversation(c)
                                1 -> shareText(viewModel.conversationShareText(c))
                                2 -> { viewModel.deleteConversation(c.id); toast("Удалено") }
                            }
                        }.show()
                }
            }
            .setNegativeButton("Закрыть", null).show()
    }

    // ---------- Настройки ----------
    private fun showSettingsMenu() {
        val provider = viewModel.getProvider()
        val items = arrayOf(
            "Провайдер API (сейчас: ${provider.displayName})",
            "API ключи (до 3, резерв)",
            "Модель API",
            "Системный промпт",
            "Промпт авто-фото",
            "Микрофон (выбор входа)",
            "Чувствительность и шёпот",
            "Задержка снимка экрана"
        )
        AlertDialog.Builder(this).setTitle("Настройки")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showProviderSelectDialog()
                    1 -> showApiKeysDialog()
                    2 -> showModelSelectDialog()
                    3 -> showSystemPromptDialog()
                    4 -> showAutoPhotoPromptDialog()
                    5 -> showMicSelectDialog()
                    6 -> showGainDialog()
                    7 -> showScreenDelayDialog()
                }
            }.show()
    }

    /** Выбор микрофона, если их несколько (встроенный, гарнитура, BT, USB). */
    private fun showMicSelectDialog() {
        val mics = viewModel.listMics()
        if (mics.isEmpty()) { toast("Доступен только системный микрофон"); return }
        val names = (listOf("Системный (по умолчанию)") + mics.map { it.name }).toTypedArray()
        val ids = (listOf(-1) + mics.map { it.id })
        val current = ids.indexOf(viewModel.getPreferredMic()).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Микрофон")
            .setSingleChoiceItems(names, current) { d, w ->
                viewModel.selectMic(ids[w]); toast("Микрофон: ${names[w]}"); d.dismiss()
            }
            .setNegativeButton("Отмена", null).show()
    }

    /** Усиление + порог тишины: чтобы разбирал даже шёпот. */
    private fun showGainDialog() {
        val gain = viewModel.getMicGain()
        val thr = viewModel.getMicThreshold()

        val lblGain = TextView(this).apply { text = "Усиление голоса: ${gain.toInt()}"; setPadding(48, 32, 48, 4) }
        val seekGain = SeekBar(this).apply { max = 11; progress = (gain - 1f).toInt().coerceIn(0, 11); setPadding(48, 4, 48, 24) }
        val lblThr = TextView(this).apply { text = "Порог тишины: ${thr.toInt()} (меньше = слышит тише)"; setPadding(48, 8, 48, 4) }
        val seekThr = SeekBar(this).apply { max = 86; progress = ((thr - 40f) / 10f).toInt().coerceIn(0, 86); setPadding(48, 4, 48, 32) }

        seekGain.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) { lblGain.text = "Усиление голоса: ${p + 1}" }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        seekThr.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) { lblThr.text = "Порог тишины: ${40 + p * 10} (меньше = слышит тише)" }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(lblGain); addView(seekGain); addView(lblThr); addView(seekThr)
        }
        AlertDialog.Builder(this)
            .setTitle("Чувствительность микрофона")
            .setMessage("Для шёпота: усиление 7-10, порог 60-120.")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                viewModel.setMicGain(seekGain.progress + 1f)
                viewModel.setMicThreshold(40f + seekThr.progress * 10f)
                toast("Сохранено. Переключи режим шёпота, чтобы применить.")
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun observeState() {
        lifecycleScope.launch {
            viewModel.uiState.collectLatest { state ->
                chatAdapter.submitList(state.messages.toList()) {
                    if (state.messages.isNotEmpty()) binding.rvMessages.smoothScrollToPosition(state.messages.size - 1)
                }
                binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE

                if (state.pendingImage != null) {
                    binding.ivPendingImage.visibility = View.VISIBLE
                    binding.btnRemoveImage.visibility = View.VISIBLE
                    binding.ivPendingImage.setImageBitmap(state.pendingImage)
                } else {
                    binding.ivPendingImage.visibility = View.GONE
                    binding.btnRemoveImage.visibility = View.GONE
                }

                val micIcon = when (state.recordingState) {
                    RecordingState.LISTENING -> android.R.drawable.ic_media_pause
                    RecordingState.PROCESSING -> android.R.drawable.ic_popup_sync
                    RecordingState.IDLE -> android.R.drawable.ic_btn_speak_now
                }
                binding.btnMic.setImageResource(micIcon)

                val btIcon = when {
                    state.ttsBlocked -> android.R.drawable.stat_sys_warning
                    else -> android.R.drawable.stat_sys_data_bluetooth
                }
                binding.btnBluetooth.setImageResource(btIcon)
                binding.btnBluetooth.alpha =
                    if (state.bluetoothMode || state.ttsBlocked || state.peerConnected) 1.0f else 0.4f

                binding.btnScreenShare.alpha = if (state.screenShareMode) 1.0f else 0.4f
                binding.btnStopTts.alpha = if (state.ttsMuted) 0.4f else 1.0f

                syncSwitch(binding.switchGallery, state.galleryWatchEnabled)
                syncSwitch(binding.switchAutoMode, state.autoPhotoMode)
                syncSwitch(binding.switchTts, state.ttsEnabled)
                syncSwitch(binding.switchAlwaysListen, state.alwaysListen)
                syncSwitch(binding.switchEcho, state.echoMode)

                binding.btnVoiceSelect.text = state.selectedVoice?.displayName?.take(20)
                    ?: if (state.ttsInitFailed) "Голос!" else "Голос"

                val progress = ((state.speechRate - 0.5f) / 0.05f).toInt().coerceIn(0, 30)
                if (binding.sliderSpeed.progress != progress) binding.sliderSpeed.progress = progress
                binding.tvSpeed.text = "%.1fx".format(state.speechRate)
            }
        }
    }

    private fun syncSwitch(sw: android.widget.CompoundButton, value: Boolean) {
        if (sw.isChecked != value) sw.isChecked = value
    }

    private fun observeEvents() {
        lifecycleScope.launch {
            viewModel.events.collectLatest { message ->
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadImageFromUri(uri: Uri) {
        try {
            val bitmap = android.graphics.BitmapFactory.decodeStream(contentResolver.openInputStream(uri))
            viewModel.setPendingImage(bitmap)
        } catch (e: Exception) { toast("Не удалось загрузить изображение") }
    }

    private fun showVoiceSelectionDialog() {
        val voices = viewModel.uiState.value.availableVoices
        if (voices.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Нет доступных голосов")
                .setMessage(if (viewModel.uiState.value.ttsInitFailed) "Нет движка TTS. Откройте настройки TTS и скачайте голоса." else "Голоса не найдены.")
                .setPositiveButton("Скачать голоса") { _, _ -> openTtsVoiceSettings() }
                .setNegativeButton("Отмена", null).show()
            return
        }
        val names = voices.map { it.displayName }.toTypedArray()
        val current = voices.indexOf(viewModel.uiState.value.selectedVoice)
        AlertDialog.Builder(this).setTitle("Выберите голос (сохранится)")
            .setSingleChoiceItems(names, current) { dialog, which -> viewModel.setVoice(voices[which]); dialog.dismiss() }
            .setNeutralButton("Ещё голоса") { _, _ -> openTtsVoiceSettings() }
            .setNegativeButton("Отмена", null).show()
    }

    private fun openTtsVoiceSettings() {
        try { startActivity(viewModel.ttsManager.getInstallVoiceDataIntent()) }
        catch (e: ActivityNotFoundException) {
            try { startActivity(viewModel.ttsManager.getTtsSettingsIntent()) }
            catch (e2: ActivityNotFoundException) { toast("Нет экрана установки голосов. Установите Google TTS.") }
        }
    }

    private fun showProviderSelectDialog() {
        val providers = ApiProvider.entries.toTypedArray()
        val names = providers.map { it.displayName }.toTypedArray()
        val current = providers.indexOf(viewModel.getProvider())
        AlertDialog.Builder(this).setTitle("Провайдер API")
            .setSingleChoiceItems(names, current) { dialog, which ->
                val chosen = providers[which]
                viewModel.setProvider(chosen)
                toast("Провайдер: ${chosen.displayName}")
                dialog.dismiss()
                if (viewModel.getApiKey(chosen).isBlank()) showApiKeysDialog()
            }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun showApiKeyDialog() = showApiKeysDialog()

    private fun showApiKeysDialog() {
        val provider = viewModel.getProvider()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
        }
        val fields = (0 until ClaudeApiClient.MAX_KEYS).map { idx ->
            EditText(this).apply {
                hint = if (idx == 0) "${provider.keyHint} (основной)" else "Резервный ключ ${idx + 1}"
                setText(viewModel.getApiKey(provider, idx))
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }.also { container.addView(it) }
        }
        AlertDialog.Builder(this)
            .setTitle("${provider.displayName}: API ключи")
            .setMessage("Если основной не работает — мгновенно используется следующий. Ключ Groq нужен ещё и для режима шёпота.")
            .setView(container)
            .setPositiveButton("Сохранить") { _, _ ->
                fields.forEachIndexed { idx, f -> viewModel.saveApiKey(provider, idx, f.text.toString().trim()) }
                val first = viewModel.getApiKey(provider, 0)
                if (first.isNotBlank()) lifecycleScope.launch {
                    val valid = viewModel.validateApiKey(provider, first)
                    toast(if (valid) "Основной ключ действителен" else "Основной ключ недействителен")
                }
            }
            .setNeutralButton("Сменить провайдера") { _, _ -> showProviderSelectDialog() }
            .setNegativeButton("Отмена", null).show()
    }

    private fun showModelSelectDialog() {
        val provider = viewModel.getProvider()
        AlertDialog.Builder(this).setTitle("Модель ${provider.displayName}")
            .setItems(arrayOf("Текстовая: ${viewModel.getTextModel(provider)}", "Vision: ${viewModel.getVisionModel(provider)}")) { _, which ->
                if (which == 0) chooseModel(provider, provider.textModels, viewModel.getTextModel(provider), true)
                else chooseModel(provider, provider.visionModels, viewModel.getVisionModel(provider), false)
            }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun chooseModel(provider: ApiProvider, known: List<String>, current: String, isText: Boolean) {
        val options = known + "Своя модель..."
        val cur = known.indexOf(current)
        AlertDialog.Builder(this)
            .setTitle(if (isText) "Текстовая модель" else "Vision модель")
            .setSingleChoiceItems(options.toTypedArray(), cur) { dialog, which ->
                if (which == known.size) {
                    dialog.dismiss(); customModelDialog(provider, current, isText)
                } else {
                    if (isText) viewModel.setTextModel(provider, known[which]) else viewModel.setVisionModel(provider, known[which])
                    toast("Модель: ${known[which]}"); dialog.dismiss()
                }
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun customModelDialog(provider: ApiProvider, current: String, isText: Boolean) {
        val et = EditText(this).apply { setText(current); setPadding(48, 24, 48, 24) }
        AlertDialog.Builder(this).setTitle("ID модели").setView(et)
            .setPositiveButton("Сохранить") { _, _ ->
                val m = et.text.toString().trim()
                if (m.isNotBlank()) {
                    if (isText) viewModel.setTextModel(provider, m) else viewModel.setVisionModel(provider, m)
                    toast("Модель: $m")
                }
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun showSystemPromptDialog() {
        val editText = EditText(this).apply {
            setText(viewModel.uiState.value.systemPrompt); minLines = 4
            gravity = android.view.Gravity.TOP; setPadding(48, 24, 48, 24)
        }
        AlertDialog.Builder(this).setTitle("Системный промпт")
            .setMessage("Задаёт личность ИИ. Запрет на разметку и мусор в озвучке добавляется автоматически.")
            .setView(editText)
            .setPositiveButton("Сохранить") { _, _ ->
                val p = editText.text.toString().trim(); if (p.isNotBlank()) viewModel.saveSystemPrompt(p)
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun showAutoPhotoPromptDialog() {
        val editText = EditText(this).apply {
            setText(viewModel.uiState.value.autoPhotoPrompt); minLines = 3
            gravity = android.view.Gravity.TOP; setPadding(48, 24, 48, 24)
        }
        AlertDialog.Builder(this).setTitle("Промпт авто-фото")
            .setMessage("Отправляется автоматически, когда появляется новое фото")
            .setView(editText)
            .setPositiveButton("Сохранить") { _, _ ->
                val p = editText.text.toString().trim(); if (p.isNotBlank()) viewModel.saveAutoPhotoPrompt(p)
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
