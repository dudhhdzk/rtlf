package com.claude.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedMessage(val role: String, val text: String)
data class SavedConversation(val id: Long, val title: String, val createdAt: Long, val messages: List<SavedMessage>)

class ConversationStore(context: Context) {
    private val prefs = context.getSharedPreferences("claude_convos", Context.MODE_PRIVATE)
    private val KEY = "conversations"

    fun list(): List<SavedConversation> {
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = ArrayList<SavedConversation>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val msgs = ArrayList<SavedMessage>()
            val ma = o.optJSONArray("messages") ?: JSONArray()
            for (j in 0 until ma.length()) {
                val m = ma.getJSONObject(j)
                msgs.add(SavedMessage(m.optString("role"), m.optString("text")))
            }
            out.add(SavedConversation(o.optLong("id"), o.optString("title"), o.optLong("createdAt"), msgs))
        }
        return out.sortedByDescending { it.createdAt }
    }

    fun save(messages: List<SavedMessage>): SavedConversation {
        val title = messages.firstOrNull { it.role == "user" && it.text.isNotBlank() }?.text?.take(40)?.ifBlank { "Диалог" } ?: "Диалог"
        val convo = SavedConversation(System.currentTimeMillis(), title, System.currentTimeMillis(), messages)
        val all = list().toMutableList()
        all.add(convo)
        persist(all)
        return convo
    }

    fun delete(id: Long) = persist(list().filter { it.id != id })

    private fun persist(all: List<SavedConversation>) {
        val arr = JSONArray()
        for (c in all) {
            val ma = JSONArray()
            for (m in c.messages) ma.put(JSONObject().apply { put("role", m.role); put("text", m.text) })
            arr.put(JSONObject().apply {
                put("id", c.id); put("title", c.title); put("createdAt", c.createdAt); put("messages", ma)
            })
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun toShareText(c: SavedConversation): String {
        val sb = StringBuilder("${c.title}\n\n")
        for (m in c.messages) {
            val who = if (m.role == "user") "Я" else "AI"
            sb.append("$who: ${m.text}\n\n")
        }
        sb.append("— отправлено из Claude AI")
        return sb.toString()
    }
}
