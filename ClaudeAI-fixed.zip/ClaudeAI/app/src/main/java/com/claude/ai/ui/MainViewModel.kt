package com.claude.ai.ui

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.claude.ai.api.ApiProvider
import com.claude.ai.api.ClaudeApiClient
import com.claude.ai.api.Message
import com.claude.ai.audio.AudioRecordManager
import com.claude.ai.audio.MicDevice
import com.claude.ai.audio.RecordingState
import com.claude.ai.audio.TTSManager
import com.claude.ai.audio.VoiceInfo
import com.claude.ai.audio.WhisperAudioManager
import com.claude.ai.bluetooth.BluetoothChatManager
import com.claude.ai.bluetooth.BluetoothMonitor
import com.claude.ai.bluetooth.BtLinkState
import com.claude.ai.camera.GalleryObserver
import com.claude.ai.data.ConversationStore
import com.claude.ai.data.SavedConversation
import com.claude.ai.data.SavedMessage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: Long = System.currentTimeMillis(),
    val role: String,
    val text: String,
    val image: Bitmap? = null,
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val fromPeer: Boolean = false
)

/** Запрос на снимок экрана: промпт + задержка (успеть открыть другое приложение). */
data class ScreenCaptureRequest(val prompt: String, val delayMs: Long)

data class UiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val galleryWatchEnabled: Boolean = false,
    val autoPhotoMode: Boolean = false,
    val ttsEnabled: Boolean = true,
    val pendingImage: Bitmap? = null,
    val recordingState: RecordingState = RecordingState.IDLE,
    val availableVoices: List<VoiceInfo> = emptyList(),
    val ttsInitFailed: Boolean = false,
    val selectedVoice: VoiceInfo? = null,
    val speechRate: Float = 1.0f,
    val streamingText: String = "",
    val systemPrompt: String = "",
    val autoPhotoPrompt: String = "",
    val apiProvider: ApiProvider = ApiProvider.GROQ,
    val alwaysListen: Boolean = false,
    val echoMode: Boolean = false,
    val bluetoothMode: Boolean = false,
    val bluetoothConnected: Boolean = false,
    val ttsBlocked: Boolean = false,
    val ttsMuted: Boolean = false,
    val screenShareMode: Boolean = false,
    val screenShareDelaySec: Int = 5,
    val micGain: Float = 5f,
    val peerConnected: Boolean = false,
    val peerName: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val apiClient = ClaudeApiClient(application)
    val audioManager = AudioRecordManager(application)
    val whisperAudio = WhisperAudioManager(application)
    val ttsManager = TTSManager(application)
    private val store = ConversationStore(application)
    private val prefs = application.getSharedPreferences("claude_prefs", Context.MODE_PRIVATE)

    private val galleryObserver = GalleryObserver(
        application,
        onNewPhoto = { bitmap, uri -> onNewGalleryPhoto(bitmap, uri) },
        onError = { msg -> emitEvent(msg) }
    )

    private val bluetoothMonitor = BluetoothMonitor(
        application,
        onConnected = { name ->
            ttsManager.setMuted(false)
            _uiState.update { it.copy(bluetoothConnected = true, ttsBlocked = false, ttsMuted = false) }
            emitEvent("Bluetooth подключён: $name")
        },
        onDisconnected = { name ->
            // Мгновенно: сначала глушим звук, потом обновляем UI.
            ttsManager.setMuted(true)
            ttsManager.stop()
            _uiState.update { it.copy(bluetoothConnected = false, ttsBlocked = true, ttsMuted = true) }
            emitEvent("Bluetooth ($name) отключён — озвучка остановлена")
        }
    )

    /** Общий диалог с другом по Bluetooth. */
    private val btChat = BluetoothChatManager(
        application,
        onMessage = { pm ->
            viewModelScope.launch {
                _uiState.update {
                    it.copy(messages = it.messages + ChatMessage(role = pm.role, text = pm.text, fromPeer = true))
                }
                if (pm.role == "user") {
                    // Реплика друга — отвечает ИИ, ответ увидят оба.
                    sendMessage(pm.text, fromPeer = true)
                } else if (_uiState.value.ttsEnabled && !ttsManager.isMuted()) {
                    ttsManager.speak(pm.text)
                }
            }
        },
        onStateChange = { st, info ->
            val connected = st == BtLinkState.CONNECTED
            _uiState.update { it.copy(peerConnected = connected, peerName = if (connected) info else "") }
            if (info.isNotBlank()) emitEvent("BT: $info")
        }
    )

    private val _uiState = MutableStateFlow(
        UiState(
            systemPrompt = apiClient.getSystemPrompt(),
            autoPhotoPrompt = apiClient.getAutoPhotoPrompt(),
            apiProvider = apiClient.getProvider(),
            speechRate = ttsManager.getSpeechRate(),
            micGain = whisperAudio.getGain(),
            screenShareDelaySec = prefs.getInt("screen_delay_sec", 5)
        )
    )
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()
    private fun emitEvent(msg: String) { _events.tryEmit(msg) }

    /** Распознанный текст, который надо положить в поле ввода (а НЕ отправлять). */
    private val _transcriptToInput = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val transcriptToInput: SharedFlow<String> = _transcriptToInput.asSharedFlow()

    private val _screenCaptureRequests = MutableSharedFlow<ScreenCaptureRequest>(extraBufferCapacity = 2)
    val screenCaptureRequests: SharedFlow<ScreenCaptureRequest> = _screenCaptureRequests.asSharedFlow()

    private val conversationHistory = mutableListOf<Message>()
    private var streamingJob: Job? = null

    init {
        audioManager.initialize()
        ttsManager.initialize(
            onInit = { voices ->
                val saved = ttsManager.getSavedVoiceName()
                _uiState.update {
                    it.copy(
                        availableVoices = voices,
                        selectedVoice = voices.firstOrNull { v -> v.name == saved } ?: voices.firstOrNull(),
                        ttsInitFailed = ttsManager.isInitFailed()
                    )
                }
            },
            onDone = {}
        )
        viewModelScope.launch {
            audioManager.recordingState.collect { state ->
                if (!whisperAudio.running) _uiState.update { it.copy(recordingState = state) }
            }
        }
        viewModelScope.launch {
            whisperAudio.state.collect { state ->
                if (whisperAudio.running) _uiState.update { it.copy(recordingState = state) }
            }
        }
    }

    // ---------- Галерея ----------
    /** Слежение за галереей. Полностью независимо от авто-режима. */
    fun setGalleryWatch(enabled: Boolean) {
        _uiState.update { it.copy(galleryWatchEnabled = enabled) }
        if (enabled) galleryObserver.startObserving()
        else if (!_uiState.value.autoPhotoMode) galleryObserver.stopObserving()
    }

    private fun onNewGalleryPhoto(bitmap: Bitmap, uri: Uri) {
        val s = _uiState.value
        if (!s.galleryWatchEnabled && !s.autoPhotoMode) return
        _uiState.update { it.copy(pendingImage = bitmap) }
        // Только режим слежения сам отправляет фото. Авто-режим ждёт голос.
        if (s.galleryWatchEnabled && !s.autoPhotoMode) sendMessage(s.autoPhotoPrompt, bitmap)
    }

    fun setPendingImage(bitmap: Bitmap?) { _uiState.update { it.copy(pendingImage = bitmap) } }

    fun attachLatestPhoto() {
        val bitmap = galleryObserver.getLatestPhoto()
        if (bitmap != null) _uiState.update { it.copy(pendingImage = bitmap) }
        else emitEvent("Нет доступных фото в галерее")
    }

    // ---------- Отправка ----------
    fun sendMessage(text: String, overrideImage: Bitmap? = null, fromPeer: Boolean = false) {
        val state = _uiState.value
        val imageBitmap = overrideImage ?: state.pendingImage
        if (text.isBlank() && imageBitmap == null) return
        if (state.isLoading) return

        val assistantId = System.currentTimeMillis() + 1
        val newMessages = mutableListOf<ChatMessage>()
        // Реплика друга уже добавлена в чат при приёме — не дублируем.
        if (!fromPeer) newMessages.add(ChatMessage(role = "user", text = text, image = imageBitmap))
        newMessages.add(ChatMessage(id = assistantId, role = "assistant", text = "", isStreaming = true))

        _uiState.update {
            it.copy(messages = it.messages + newMessages, isLoading = true, pendingImage = null, streamingText = "")
        }

        // Твоя реплика улетает другу в общий диалог.
        if (!fromPeer && btChat.isConnected() && text.isNotBlank()) btChat.send("user", text)

        val messageContent = when {
            text.isNotBlank() -> text
            imageBitmap != null -> state.autoPhotoPrompt
            else -> "Привет"
        }
        conversationHistory.add(Message(role = "user", content = messageContent, imageBitmap = imageBitmap))

        streamingJob = viewModelScope.launch {
            var fullResponse = ""
            apiClient.sendMessageStream(conversationHistory, systemPrompt = state.systemPrompt).collect { chunk ->
                when {
                    chunk.error != null -> {
                        // Ошибки не озвучиваем.
                        updateStreamingMessage(assistantId, chunk.error, isError = true, isStreaming = false)
                        _uiState.update { it.copy(isLoading = false) }
                    }
                    chunk.isComplete -> {
                        updateStreamingMessage(assistantId, fullResponse, isStreaming = false)
                        conversationHistory.add(Message(role = "assistant", content = fullResponse))
                        _uiState.update { it.copy(isLoading = false, streamingText = "") }
                        if (_uiState.value.ttsEnabled && !ttsManager.isMuted() && fullResponse.isNotBlank()) {
                            ttsManager.speak(fullResponse)
                        }
                        if (btChat.isConnected() && fullResponse.isNotBlank()) btChat.send("assistant", fullResponse)
                    }
                    else -> {
                        fullResponse += chunk.text
                        _uiState.update { it.copy(streamingText = fullResponse) }
                        updateStreamingMessage(assistantId, fullResponse, isStreaming = true)
                    }
                }
            }
        }
    }

    private fun updateStreamingMessage(id: Long, text: String, isStreaming: Boolean = true, isError: Boolean = false) {
        _uiState.update { state ->
            val updated = state.messages.map { msg ->
                if (msg.id == id) msg.copy(text = text, isStreaming = isStreaming, isError = isError) else msg
            }
            state.copy(messages = updated)
        }
    }

    // ---------- Голос ----------
    private fun isStopWord(text: String): Boolean {
        val t = text.trim().lowercase().trimEnd('.', '!', ',')
        return t == "стоп" || t == "stop" || t.startsWith("стоп ") || t.endsWith(" стоп")
    }

    /**
     * @param autoSend true — отправляем сразу (кнопка микрофона, авто-режим).
     *                 false — кладём текст в поле ввода, ничего не отправляем.
     */
    private fun onVoiceResult(text: String, autoSend: Boolean) {
        val t = text.trim()
        if (t.isBlank()) return
        val s = _uiState.value

        if (isStopWord(t)) {
            ttsManager.setMuted(true)
            _uiState.update { it.copy(ttsEnabled = false, ttsMuted = true) }
            emitEvent("Озвучка выключена (сказано «стоп»)")
            return
        }
        if (s.echoMode) { ttsManager.speak(t); return }
        if (s.screenShareMode) { requestScreenCapture(t); return }
        if (s.autoPhotoMode) { sendMessage(t, galleryObserver.getLatestPhoto()); return }
        if (autoSend) sendMessage(t) else _transcriptToInput.tryEmit(t)
    }

    fun startVoiceInput() {
        if (!audioManager.isAvailable()) { emitEvent("Распознавание недоступно. Включите режим шёпота."); return }
        audioManager.startListening("ru-RU", onResult = { onVoiceResult(it, autoSend = true) }, onError = { emitEvent(it) })
    }
    fun stopVoiceInput() = audioManager.stopListening()

    /**
     * Режим шёпота: свой микрофон с усилением + Whisper.
     * Ничего сам не отправляет — распознанное падает в поле ввода.
     */
    fun setAlwaysListen(enabled: Boolean) {
        _uiState.update { it.copy(alwaysListen = enabled) }
        if (enabled) {
            whisperAudio.start(
                onUtterance = { wav ->
                    viewModelScope.launch {
                        val text = apiClient.transcribe(wav, "ru")
                        when {
                            text == "__NO_GROQ_KEY__" -> {
                                emitEvent("Для режима шёпота нужен ключ Groq (Настройки — API ключи)")
                                setAlwaysListen(false)
                            }
                            text.isNotBlank() -> onVoiceResult(text, autoSend = _uiState.value.autoPhotoMode)
                        }
                    }
                },
                onError = { emitEvent(it) }
            )
            emitEvent("Режим шёпота включён (усиление ${whisperAudio.getGain().toInt()})")
        } else whisperAudio.stop()
    }

    fun setEchoMode(enabled: Boolean) { _uiState.update { it.copy(echoMode = enabled) } }

    // ---------- Микрофон: выбор устройства и чувствительность ----------
    fun listMics(): List<MicDevice> = whisperAudio.availableMics()
    fun selectMic(id: Int) { whisperAudio.setPreferredMic(id) }
    fun getPreferredMic(): Int = whisperAudio.getPreferredMic()
    fun setMicGain(g: Float) { whisperAudio.setGain(g); _uiState.update { it.copy(micGain = whisperAudio.getGain()) } }
    fun getMicGain(): Float = whisperAudio.getGain()
    fun setMicThreshold(v: Float) = whisperAudio.setThreshold(v)
    fun getMicThreshold(): Float = whisperAudio.getThreshold()

    // ---------- Авто-режим (микрофон + фото) ----------
    /** Включает микрофон САМ. Галерею-слежение не трогает — это отдельный тумблер. */
    fun setAutoPhotoMode(enabled: Boolean) {
        _uiState.update { it.copy(autoPhotoMode = enabled) }
        if (enabled) {
            galleryObserver.startObserving()
            if (!_uiState.value.alwaysListen) setAlwaysListen(true)
        } else {
            if (!_uiState.value.galleryWatchEnabled) galleryObserver.stopObserving()
        }
    }

    // ---------- Озвучка ----------
    fun setTtsEnabled(enabled: Boolean) {
        _uiState.update { it.copy(ttsEnabled = enabled, ttsMuted = !enabled) }
        ttsManager.setMuted(!enabled)
        if (!enabled) ttsManager.stop()
    }

    /** Кнопка «Слушать/Стоп»: ТОЛЬКО глушит озвучку. Никаких отправок сообщений. */
    fun toggleSpeechMute() {
        val mute = !ttsManager.isMuted()
        ttsManager.setMuted(mute)
        if (mute) ttsManager.stop()
        _uiState.update { it.copy(ttsMuted = mute, ttsEnabled = !mute) }
        emitEvent(if (mute) "Озвучка выключена" else "Озвучка включена")
    }

    fun setVoice(voice: VoiceInfo) { _uiState.update { it.copy(selectedVoice = voice) }; ttsManager.setVoice(voice) }
    fun setSpeechRate(rate: Float) { _uiState.update { it.copy(speechRate = rate) }; ttsManager.setSpeechRate(rate) }
    fun stopTts() = ttsManager.stop()

    // ---------- Bluetooth: аудио-мониторинг ----------
    fun setBluetoothMode(enabled: Boolean) {
        _uiState.update { it.copy(bluetoothMode = enabled) }
        if (enabled) {
            if (!bluetoothMonitor.hasPermission()) emitEvent("Нужно разрешение Bluetooth")
            bluetoothMonitor.start()
            _uiState.update { it.copy(bluetoothConnected = bluetoothMonitor.hasConnectedDevice()) }
        } else {
            bluetoothMonitor.stop()
            ttsManager.setMuted(false)
            _uiState.update { it.copy(bluetoothConnected = false, ttsBlocked = false, ttsMuted = false) }
        }
    }

    fun unblockTts() {
        ttsManager.setMuted(false)
        _uiState.update { it.copy(ttsBlocked = false, ttsMuted = false, ttsEnabled = true) }
        emitEvent("Озвучка возобновлена вручную")
    }

    // ---------- Bluetooth: общий диалог с другом ----------
    fun btHost() = btChat.host()
    fun btJoin(device: BluetoothDevice) = btChat.join(device)
    fun btBondedDevices(): List<BluetoothDevice> = btChat.bondedDevices()
    fun btStopChat() = btChat.stop()
    fun btIsConnected(): Boolean = btChat.isConnected()

    // ---------- Демонстрация экрана ----------
    fun setScreenShareMode(enabled: Boolean) { _uiState.update { it.copy(screenShareMode = enabled) } }

    fun setScreenShareDelay(sec: Int) {
        val d = sec.coerceIn(0, 20)
        prefs.edit().putInt("screen_delay_sec", d).apply()
        _uiState.update { it.copy(screenShareDelaySec = d) }
    }

    fun captureScreenNow() = requestScreenCapture(_uiState.value.autoPhotoPrompt)

    /** Снимок с задержкой: успеваешь открыть нужное приложение, а не своё. */
    private fun requestScreenCapture(prompt: String) {
        val d = _uiState.value.screenShareDelaySec
        if (d > 0) emitEvent("Снимок через $d сек — открой нужное приложение")
        _screenCaptureRequests.tryEmit(ScreenCaptureRequest(prompt, d * 1000L))
    }

    fun onScreenCaptured(prompt: String, bitmap: Bitmap?) {
        if (bitmap == null) { emitEvent("Не удалось снять экран"); return }
        sendMessage(prompt.ifBlank { _uiState.value.autoPhotoPrompt }, bitmap)
    }

    // ---------- Сохранённые диалоги ----------
    fun saveCurrentConversation() {
        val msgs = _uiState.value.messages.filter { it.text.isNotBlank() && !it.isError }
            .map { SavedMessage(it.role, it.text) }
        if (msgs.isEmpty()) { emitEvent("Нечего сохранять"); return }
        store.save(msgs); emitEvent("Диалог сохранён")
    }
    fun listConversations(): List<SavedConversation> = store.list()
    fun deleteConversation(id: Long) = store.delete(id)
    fun conversationShareText(c: SavedConversation): String = store.toShareText(c)
    fun loadConversation(c: SavedConversation) {
        conversationHistory.clear()
        val restored = c.messages.map { ChatMessage(role = it.role, text = it.text) }
        c.messages.forEach { conversationHistory.add(Message(role = it.role, content = it.text)) }
        _uiState.update { it.copy(messages = restored, streamingText = "", isLoading = false) }
    }

    fun clearConversation() {
        streamingJob?.cancel(); conversationHistory.clear()
        _uiState.update { it.copy(messages = emptyList(), isLoading = false, streamingText = "") }
    }

    // ---------- Провайдер / модели / ключи ----------
    fun getProvider(): ApiProvider = apiClient.getProvider()
    fun setProvider(provider: ApiProvider) { apiClient.setProvider(provider); _uiState.update { it.copy(apiProvider = provider) } }

    fun getApiKey(): String = apiClient.getApiKey()
    fun getApiKey(provider: ApiProvider): String = apiClient.getApiKey(provider)
    fun getApiKey(provider: ApiProvider, index: Int): String = apiClient.getApiKey(provider, index)
    fun saveApiKey(key: String) = apiClient.setApiKey(key)
    fun saveApiKey(provider: ApiProvider, key: String) = apiClient.setApiKey(provider, key)
    fun saveApiKey(provider: ApiProvider, index: Int, key: String) = apiClient.setApiKey(provider, index, key)
    suspend fun validateApiKey(key: String): Boolean = apiClient.validateApiKey(key)
    suspend fun validateApiKey(provider: ApiProvider, key: String): Boolean = apiClient.validateApiKey(provider, key)

    fun getTextModel(provider: ApiProvider = getProvider()): String = apiClient.getTextModel(provider)
    fun setTextModel(provider: ApiProvider, model: String) = apiClient.setTextModel(provider, model)
    fun getVisionModel(provider: ApiProvider = getProvider()): String = apiClient.getVisionModel(provider)
    fun setVisionModel(provider: ApiProvider, model: String) = apiClient.setVisionModel(provider, model)

    fun saveSystemPrompt(prompt: String) { apiClient.setSystemPrompt(prompt); _uiState.update { it.copy(systemPrompt = prompt) } }
    fun saveAutoPhotoPrompt(prompt: String) { apiClient.setAutoPhotoPrompt(prompt); _uiState.update { it.copy(autoPhotoPrompt = prompt) } }

    override fun onCleared() {
        super.onCleared()
        galleryObserver.stopObserving()
        audioManager.destroy()
        whisperAudio.release()
        ttsManager.destroy()
        bluetoothMonitor.stop()
        btChat.release()
        streamingJob?.cancel()
    }
}
