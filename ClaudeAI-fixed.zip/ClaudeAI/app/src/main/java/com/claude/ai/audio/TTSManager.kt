package com.claude.ai.audio

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

data class VoiceInfo(
    val name: String,
    val displayName: String,
    val locale: Locale,
    val quality: Int,
    val isNetworkRequired: Boolean
)

class TTSManager(private val context: Context) {

    companion object {
        private const val TAG = "TTSManager"
        private const val UTTERANCE_ID = "claude_tts"
        private const val PREF_VOICE = "selected_voice"
        private const val PREF_RATE = "speech_rate"
        private const val PREF_PITCH = "speech_pitch"
    }

    private val prefs = context.getSharedPreferences("claude_prefs", Context.MODE_PRIVATE)

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var initFailed = false
    private var pendingText: String? = null
    private var availableVoices: List<VoiceInfo> = emptyList()

    /** Гейт: muted = true (например, Bluetooth отвалился) — не озвучиваем ничего. */
    @Volatile private var muted = false

    private var onSpeakStart: (() -> Unit)? = null
    private var onSpeakDone: (() -> Unit)? = null
    private var onInitialized: ((List<VoiceInfo>) -> Unit)? = null

    fun initialize(
        onInit: (List<VoiceInfo>) -> Unit,
        onStart: () -> Unit = {},
        onDone: () -> Unit = {}
    ) {
        onInitialized = onInit; onSpeakStart = onStart; onSpeakDone = onDone
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                setupTTS()
                availableVoices = loadAvailableVoices()
                restoreSavedVoice()
                onInitialized?.invoke(availableVoices)
                Log.d(TAG, "TTS initialized. Found ${availableVoices.size} voices")
                pendingText?.let { speak(it) }; pendingText = null
            } else {
                initFailed = true; isInitialized = false
                Log.e(TAG, "TTS init failed: $status")
                onInitialized?.invoke(emptyList())
            }
        }
    }

    fun isInitFailed(): Boolean = initFailed

    /** Мгновенно обрывает речь и запрещает новую. */
    fun setMuted(value: Boolean) {
        muted = value
        if (value) { tts?.stop() }
    }
    fun isMuted(): Boolean = muted

    fun getInstallVoiceDataIntent(): Intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
    fun getTtsSettingsIntent(): Intent = Intent().apply { action = "com.android.settings.TTS_SETTINGS" }

    private fun setupTTS() {
        tts?.apply {
            val result = setLanguage(Locale("ru", "RU"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) setLanguage(Locale.ENGLISH)
            setSpeechRate(prefs.getFloat(PREF_RATE, 1.0f))
            setPitch(prefs.getFloat(PREF_PITCH, 1.0f))
            // Медиа-поток: уходит в Bluetooth-наушники параллельно с RFCOMM-каналом друга.
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { onSpeakStart?.invoke() }
                override fun onDone(utteranceId: String?) { onSpeakDone?.invoke() }
                @Deprecated("deprecated") override fun onError(utteranceId: String?) { onSpeakDone?.invoke() }
            })
        }
    }

    /** Восстанавливает голос, выбранный в прошлый запуск. */
    private fun restoreSavedVoice() {
        val saved = prefs.getString(PREF_VOICE, null) ?: return
        tts?.voices?.find { it.name == saved }?.let { tts?.voice = it }
    }

    private fun loadAvailableVoices(): List<VoiceInfo> {
        val voices = tts?.voices ?: return emptyList()
        return voices
            .filter { !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) }
            .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.locale.displayName })
            .map { VoiceInfo(it.name, buildDisplayName(it), it.locale, it.quality, it.isNetworkConnectionRequired) }
            .distinctBy { it.displayName }
    }

    private fun buildDisplayName(voice: Voice): String {
        val lang = voice.locale.getDisplayLanguage(Locale.getDefault())
        val country = voice.locale.getDisplayCountry(Locale.getDefault())
        val quality = when { voice.quality >= 500 -> "3*"; voice.quality >= 300 -> "2*"; else -> "1*" }
        val network = if (voice.isNetworkConnectionRequired) " (сеть)" else ""
        return "$lang ($country) $quality$network"
    }

    /**
     * Чистит текст перед озвучкой: убирает markdown, звёздочки, эмодзи, код,
     * и схлопывает случайные повторы слов ("привет привет" -> "привет").
     */
    fun sanitizeForSpeech(raw: String): String {
        var t = raw
        t = t.replace(Regex("(?s)```.*?```"), " ")
        t = t.replace(Regex("`[^`]*`"), " ")
        t = t.replace(Regex("(?m)^\\s*#{1,6}\\s*"), "")
        t = t.replace(Regex("(?m)^\\s*>\\s*"), "")
        t = t.replace(Regex("(?m)^\\s*[-*+•]\\s+"), "")
        t = t.replace(Regex("(?m)^\\s*\\d+[.)]\\s+"), "")
        t = t.replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
        t = t.replace(Regex("https?://\\S+"), " ссылка ")
        t = t.replace(Regex("[*_~#>|^]+"), " ")
        t = t.replace(Regex("[\\p{So}\\p{Cn}]"), " ")
        t = t.replace(Regex("(?iu)\\b(\\p{L}{2,})(\\s+\\1\\b)+"), "$1")
        t = t.replace(Regex("([.!?,:;])\\1+"), "$1")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    fun speak(text: String, clearQueue: Boolean = true) {
        if (muted) { Log.d(TAG, "speak() ignored: muted"); return }
        val clean = sanitizeForSpeech(text)
        if (clean.isBlank()) return
        if (!isInitialized) { pendingText = clean; return }
        val chunks = splitTextIntoChunks(clean, 500)
        val queueMode = if (clearQueue) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        chunks.forEachIndexed { index, chunk ->
            if (muted) return
            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "${UTTERANCE_ID}_$index")
            tts?.speak(chunk, if (index == 0) queueMode else TextToSpeech.QUEUE_ADD, params, "${UTTERANCE_ID}_$index")
        }
    }

    fun stop() { tts?.stop() }
    fun isSpeaking(): Boolean = tts?.isSpeaking == true

    /** Выбор голоса + сохранение, чтобы пережил перезапуск приложения. */
    fun setVoice(voiceInfo: VoiceInfo) {
        tts?.voices?.find { it.name == voiceInfo.name }?.let {
            tts?.voice = it
            prefs.edit().putString(PREF_VOICE, voiceInfo.name).apply()
        }
    }

    fun getSavedVoiceName(): String? = prefs.getString(PREF_VOICE, null)

    fun setSpeechRate(rate: Float) {
        val r = rate.coerceIn(0.5f, 2.0f)
        tts?.setSpeechRate(r)
        prefs.edit().putFloat(PREF_RATE, r).apply()
    }
    fun getSpeechRate(): Float = prefs.getFloat(PREF_RATE, 1.0f)

    fun setPitch(pitch: Float) {
        val p = pitch.coerceIn(0.5f, 2.0f)
        tts?.setPitch(p)
        prefs.edit().putFloat(PREF_PITCH, p).apply()
    }

    fun getAvailableVoices(): List<VoiceInfo> = availableVoices
    fun getCurrentVoice(): VoiceInfo? = tts?.voice?.let { cur -> availableVoices.find { it.name == cur.name } }

    private fun splitTextIntoChunks(text: String, maxLength: Int): List<String> {
        if (text.length <= maxLength) return listOf(text)
        val chunks = mutableListOf<String>(); var start = 0
        while (start < text.length) {
            var end = minOf(start + maxLength, text.length)
            if (end < text.length) {
                val bp = maxOf(text.lastIndexOf('.', end), text.lastIndexOf('?', end), text.lastIndexOf('!', end))
                if (bp > start) end = bp + 1
            }
            chunks.add(text.substring(start, end).trim()); start = end
        }
        return chunks.filter { it.isNotBlank() }
    }

    fun destroy() { tts?.stop(); tts?.shutdown(); tts = null }
}
