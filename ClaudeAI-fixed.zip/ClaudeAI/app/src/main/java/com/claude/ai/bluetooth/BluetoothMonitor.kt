package com.claude.ai.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager as SysBluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Следит за Bluetooth-аудио. При обрыве дёргает onDisconnected МГНОВЕННО:
 * слушаем и ACTION_AUDIO_BECOMING_NOISY (звук вот-вот уйдёт на динамик) —
 * это срабатывает раньше, чем ACL_DISCONNECTED и опрос профилей.
 */
class BluetoothMonitor(
    private val context: Context,
    private val onConnected: (String) -> Unit,
    private val onDisconnected: (String) -> Unit
) {
    companion object { private const val TAG = "BluetoothMonitor" }

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected

    private var receiver: BroadcastReceiver? = null
    private var registered = false

    fun hasPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        else true

    private fun adapter(): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? SysBluetoothManager)?.adapter

    @SuppressLint("MissingPermission")
    fun start() {
        if (registered) return
        if (!hasPermission()) { Log.w(TAG, "No BLUETOOTH_CONNECT permission"); return }
        _connected.value = hasConnectedDevice()

        receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val device: BluetoothDevice? =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                        intent?.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    else @Suppress("DEPRECATION") intent?.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                val name = safeName(device)
                when (intent?.action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> {
                        _connected.value = true; onConnected(name)
                    }
                    // Мгновенно: глушим, не дожидаясь опроса профилей.
                    BluetoothDevice.ACTION_ACL_DISCONNECTED,
                    AudioManager.ACTION_AUDIO_BECOMING_NOISY -> {
                        _connected.value = false
                        onDisconnected(name)
                    }
                    BluetoothAdapter.ACTION_STATE_CHANGED -> {
                        val st = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.STATE_OFF)
                        if (st == BluetoothAdapter.STATE_TURNING_OFF || st == BluetoothAdapter.STATE_OFF) {
                            _connected.value = false
                            onDisconnected("Bluetooth выключен")
                        }
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        registered = true
    }

    @SuppressLint("MissingPermission")
    fun safeName(device: BluetoothDevice?): String =
        try { device?.name ?: "устройство" } catch (e: SecurityException) { "устройство" }

    @SuppressLint("MissingPermission")
    fun hasConnectedDevice(): Boolean {
        val a = adapter() ?: return false
        if (!a.isEnabled) return false
        return try {
            a.getProfileConnectionState(BluetoothProfile.A2DP) == BluetoothProfile.STATE_CONNECTED ||
            a.getProfileConnectionState(BluetoothProfile.HEADSET) == BluetoothProfile.STATE_CONNECTED
        } catch (e: SecurityException) { false }
    }

    fun isConnected(): Boolean = _connected.value

    fun stop() {
        if (registered) {
            try { context.unregisterReceiver(receiver) } catch (e: Exception) { }
            registered = false
        }
        receiver = null
    }
}
