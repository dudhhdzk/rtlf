package com.claude.ai.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.claude.ai.R

class ChatAdapter : ListAdapter<ChatMessage, RecyclerView.ViewHolder>(ChatDiffCallback()) {
    companion object { private const val VIEW_TYPE_USER = 0; private const val VIEW_TYPE_ASSISTANT = 1 }

    override fun getItemViewType(position: Int): Int =
        if (getItem(position).role == "user") VIEW_TYPE_USER else VIEW_TYPE_ASSISTANT

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_USER) {
            UserMessageViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_message_user, parent, false))
        } else {
            AssistantMessageViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_message_assistant, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = getItem(position)
        when (holder) {
            is UserMessageViewHolder -> holder.bind(message)
            is AssistantMessageViewHolder -> holder.bind(message)
        }
    }

    class UserMessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvText: TextView = view.findViewById(R.id.tvMessage)
        private val ivImage: ImageView = view.findViewById(R.id.ivImage)
        fun bind(message: ChatMessage) {
            val prefix = if (message.fromPeer) "[друг] " else ""
            tvText.text = (prefix + message.text).ifBlank { if (message.image != null) "Фото" else "" }
            tvText.visibility = if (message.text.isNotBlank()) View.VISIBLE else View.GONE
            if (message.image != null) { ivImage.visibility = View.VISIBLE; ivImage.setImageBitmap(message.image) }
            else ivImage.visibility = View.GONE
        }
    }

    class AssistantMessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvText: TextView = view.findViewById(R.id.tvMessage)
        private val viewStreaming: View = view.findViewById(R.id.viewStreaming)
        fun bind(message: ChatMessage) {
            tvText.text = when {
                message.isError -> "Ошибка: ${message.text}"
                message.text.isBlank() && message.isStreaming -> "..."
                else -> message.text
            }
            viewStreaming.visibility = if (message.isStreaming) View.VISIBLE else View.GONE
            tvText.setTextColor(tvText.context.getColor(if (message.isError) android.R.color.holo_red_light else android.R.color.white))
        }
    }

    class ChatDiffCallback : DiffUtil.ItemCallback<ChatMessage>() {
        override fun areItemsTheSame(oldItem: ChatMessage, newItem: ChatMessage) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: ChatMessage, newItem: ChatMessage) = oldItem == newItem
    }
}
