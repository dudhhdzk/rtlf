package com.claude.ai.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothManager as SysBluetoothManager
import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Сообщение общего диалога, пришедшее от друга или ушедшее к нему. */
data class PeerMessage(val role: String, val text: String, val fromMe: Boolean)

enum class BtLinkState { IDLE, LISTENING, CONNECTING, CONNECTED, ERROR }

/**
 * Двухканальный общий диалог двух телефонов по Bluetooth RFCOMM.
 * Один жмёт host() (сервер ждёт), второй join(device) (клиент подключается).
 * Дальше оба видят один диалог: твои реплики и ответы ИИ летят другу и обратно.
 *
 * Важно: RFCOMM — это канал данных. Он НЕ мешает A2DP,
 * поэтому звук в Bluetooth-наушники идёт параллельно, одновременно с диалогом.
 */
class BluetoothChatManager(
    private val context: Context,
    private val onMessage: (PeerMessage) -> Unit,
    private val onStateChange: (BtLinkState, String) -> Unit
) {
    companion object {
        private const val TAG = "BtChat"
        private const val NAME = "ClaudeAIChat"
        /** Один и тот же UUID на обоих телефонах. */
        private val APP_UUID: UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var serverSocket: BluetoothServerSocket? = null
    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private var listenJob: Job? = null
    private var readJob: Job? = null

    private val _state = MutableStateFlow(BtLinkState.IDLE)
    val state: StateFlow<BtLinkState> = _state

    private var peerName: String = "друг"
    fun peerName(): String = peerName

    private fun adapter(): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? SysBluetoothManager)?.adapter

    /** Сопряжённые устройства — из них выбираешь друга. */
    @SuppressLint("MissingPermission")
    fun bondedDevices(): List<BluetoothDevice> =
        try { adapter()?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() }

    // ---------- ХОСТ ----------
    @SuppressLint("MissingPermission")
    fun host() {
        stop()
        val a = adapter() ?: run { setState(BtLinkState.ERROR, "Bluetooth недоступен"); return }
        if (!a.isEnabled) { setState(BtLinkState.ERROR, "Включите Bluetooth"); return }
        setState(BtLinkState.LISTENING, "Ждём подключения друга")
        listenJob = scope.launch {
            try {
                serverSocket = a.listenUsingRfcommWithServiceRecord(NAME, APP_UUID)
                val s = serverSocket?.accept()
                runCatching { serverSocket?.close() }; serverSocket = null
                if (s != null) onConnected(s, safeName(s.remoteDevice))
            } catch (e: Exception) {
                if (isActive) setState(BtLinkState.ERROR, "Хост: ${e.message}")
            }
        }
    }

    // ---------- КЛИЕНТ ----------
    @SuppressLint("MissingPermission")
    fun join(device: BluetoothDevice) {
        stop()
        val a = adapter() ?: run { setState(BtLinkState.ERROR, "Bluetooth недоступен"); return }
        if (!a.isEnabled) { setState(BtLinkState.ERROR, "Включите Bluetooth"); return }
        setState(BtLinkState.CONNECTING, "Подключаемся к ${safeName(device)}")
        readJob = scope.launch {
            try {
                runCatching { a.cancelDiscovery() }
                val s = device.createRfcommSocketToServiceRecord(APP_UUID)
                s.connect()
                onConnected(s, safeName(device))
            } catch (e: Exception) {
                setState(BtLinkState.ERROR, "Подключение: ${e.message}")
            }
        }
    }

    private fun onConnected(s: BluetoothSocket, name: String) {
        socket = s
        output = s.outputStream
        peerName = name
        setState(BtLinkState.CONNECTED, name)
        readLoop(s.inputStream)
    }

    private fun readLoop(input: InputStream) {
        readJob = scope.launch {
            val buf = ByteArray(4096)
            val acc = StringBuilder()
            try {
                while (isActive) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    acc.append(String(buf, 0, n, Charsets.UTF_8))
                    var nl = acc.indexOf("\n")
                    while (nl >= 0) {
                        val line = acc.substring(0, nl); acc.delete(0, nl + 1)
                        if (line.isNotBlank()) parseIncoming(line)
                        nl = acc.indexOf("\n")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "read loop ended: ${e.message}")
            }
            if (isActive) setState(BtLinkState.IDLE, "Соединение закрыто")
        }
    }

    private fun parseIncoming(line: String) {
        try {
            val j = JSONObject(line)
            val role = j.optString("role", "user")
            val text = j.optString("text", "")
            if (text.isNotBlank()) onMessage(PeerMessage(role, text, fromMe = false))
        } catch (e: Exception) {
            onMessage(PeerMessage("user", line, fromMe = false))
        }
    }

    /** role: "user" — твоя реплика, "assistant" — ответ ИИ. */
    fun send(role: String, text: String) {
        val out = output ?: return
        if (text.isBlank()) return
        scope.launch {
            try {
                val payload = JSONObject().put("role", role).put("text", text).toString() + "\n"
                out.write(payload.toByteArray(Charsets.UTF_8)); out.flush()
            } catch (e: Exception) { setState(BtLinkState.ERROR, "Отправка: ${e.message}") }
        }
    }

    fun isConnected(): Boolean = _state.value == BtLinkState.CONNECTED

    fun stop() {
        listenJob?.cancel(); readJob?.cancel()
        runCatching { serverSocket?.close() }; serverSocket = null
        runCatching { socket?.close() }; socket = null
        output = null
        if (_state.value != BtLinkState.IDLE) setState(BtLinkState.IDLE, "")
    }

    fun release() { stop(); scope.cancel() }

    private fun setState(st: BtLinkState, info: String) { _state.value = st; onStateChange(st, info) }

    @SuppressLint("MissingPermission")
    private fun safeName(d: BluetoothDevice?): String =
        try { d?.name ?: d?.address ?: "друг" } catch (e: SecurityException) { "друг" }
}
