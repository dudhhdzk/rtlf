package com.claude.ai.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

data class MicDevice(val id: Int, val name: String, val type: Int)

/**
 * Захват микрофона напрямую (AudioRecord) с программным усилением — ловит даже шёпот.
 * Системный SpeechRecognizer тихий голос режет сам, поэтому здесь свой VAD по RMS:
 * копим речь, на паузе отдаём WAV наружу (дальше — Whisper).
 *
 * Формат: PCM 16 кГц, моно, 16 бит.
 */
class WhisperAudioManager(private val context: Context) {

    companion object {
        private const val TAG = "WhisperAudio"
        private const val SAMPLE_RATE = 16_000
        private const val CHANNEL = AudioFormat.CHANNEL_IN_MONO
        private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT

        private const val SILENCE_MS = 900L
        private const val MIN_UTTERANCE_MS = 350L
        private const val MAX_UTTERANCE_MS = 15_000L

        private const val PREF_GAIN = "mic_gain"
        private const val PREF_MIC_ID = "mic_device_id"
        private const val PREF_THRESHOLD = "mic_threshold"
    }

    private val prefs = context.getSharedPreferences("claude_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var recordJob: Job? = null
    private var record: AudioRecord? = null

    /** Усиление 1..12. Для шёпота 6-10. */
    @Volatile private var gain: Float = prefs.getFloat(PREF_GAIN, 5.0f)
    /** Порог "есть голос" по RMS. Ниже = чувствительнее (ловит шёпот), но больше ложных срабатываний. */
    @Volatile private var threshold: Float = prefs.getFloat(PREF_THRESHOLD, 170f)
    @Volatile private var preferredMicId: Int = prefs.getInt(PREF_MIC_ID, -1)

    @Volatile var running = false; private set

    private val _state = MutableStateFlow(RecordingState.IDLE)
    val state: StateFlow<RecordingState> = _state

    /** Текущий уровень звука (для индикатора). */
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level

    fun setGain(value: Float) {
        gain = value.coerceIn(1.0f, 12.0f)
        prefs.edit().putFloat(PREF_GAIN, gain).apply()
    }
    fun getGain(): Float = gain

    fun setThreshold(value: Float) {
        threshold = value.coerceIn(40f, 900f)
        prefs.edit().putFloat(PREF_THRESHOLD, threshold).apply()
    }
    fun getThreshold(): Float = threshold

    /** Список доступных микрофонов: встроенный, гарнитура, Bluetooth, USB. */
    fun availableMics(): List<MicDevice> {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            .filter {
                it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            .map { MicDevice(it.id, micLabel(it.type), it.type) }
            .distinctBy { it.id }
    }

    private fun micLabel(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC   -> "Встроенный микрофон"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth-гарнитура"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Проводная гарнитура"
        AudioDeviceInfo.TYPE_USB_DEVICE    -> "USB-устройство"
        AudioDeviceInfo.TYPE_USB_HEADSET   -> "USB-гарнитура"
        else -> "Микрофон ($type)"
    }

    /** -1 = системный по умолчанию. Сохраняется между запусками. */
    fun setPreferredMic(id: Int) {
        preferredMicId = id
        prefs.edit().putInt(PREF_MIC_ID, id).apply()
        if (running) restart()
    }
    fun getPreferredMic(): Int = preferredMicId

    private var lastCallbacks: Pair<(ByteArray) -> Unit, (String) -> Unit>? = null

    private fun restart() {
        val cb = lastCallbacks ?: return
        stop(); start(cb.first, cb.second)
    }

    @SuppressLint("MissingPermission")
    fun start(onUtterance: (ByteArray) -> Unit, onError: (String) -> Unit) {
        if (running) return
        lastCallbacks = onUtterance to onError

        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL, ENCODING)
        if (minBuf <= 0) { onError("Микрофон недоступен"); return }
        val bufSize = minBuf * 2

        val ar = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE, CHANNEL, ENCODING, bufSize)
        } catch (e: SecurityException) { onError("Нет разрешения на микрофон"); return }

        if (ar.state != AudioRecord.STATE_INITIALIZED) {
            onError("Не удалось открыть микрофон"); ar.release(); return
        }

        // Выбранный пользователем вход
        if (preferredMicId != -1) {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.getDevices(AudioManager.GET_DEVICES_INPUTS)
                .firstOrNull { it.id == preferredMicId }
                ?.let { ar.preferredDevice = it }
        }

        // Аппаратные эффекты — помогают тихому голосу
        runCatching { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(ar.audioSessionId)?.enabled = true }
        runCatching { if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(ar.audioSessionId)?.enabled = true }

        record = ar
        running = true
        ar.startRecording()
        _state.value = RecordingState.LISTENING

        recordJob = scope.launch {
            val buf = ShortArray(bufSize / 2)
            val speech = ByteArrayOutputStream()
            var speaking = false
            var lastVoiceTs = 0L
            var startTs = 0L

            while (isActive && running) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) continue

                var sumSq = 0.0
                for (i in 0 until n) {
                    var s = (buf[i] * gain).toInt()
                    if (s > Short.MAX_VALUE) s = Short.MAX_VALUE.toInt()
                    if (s < Short.MIN_VALUE) s = Short.MIN_VALUE.toInt()
                    buf[i] = s.toShort()
                    sumSq += s.toDouble() * s.toDouble()
                }
                val rms = sqrt(sumSq / n)
                _level.value = (rms / 8000.0).toFloat().coerceIn(0f, 1f)
                val now = System.currentTimeMillis()

                if (rms >= threshold) {
                    if (!speaking) { speaking = true; startTs = now; speech.reset() }
                    lastVoiceTs = now
                    appendPcm(speech, buf, n)
                } else if (speaking) {
                    appendPcm(speech, buf, n) // хвост тишины, чтобы не рубить окончания
                    val silence = now - lastVoiceTs
                    val dur = now - startTs
                    if (silence >= SILENCE_MS || dur >= MAX_UTTERANCE_MS) {
                        speaking = false
                        val pcm = speech.toByteArray()
                        speech.reset()
                        if (dur >= MIN_UTTERANCE_MS && pcm.isNotEmpty()) {
                            _state.value = RecordingState.PROCESSING
                            val wav = pcmToWav(pcm, SAMPLE_RATE)
                            withContext(Dispatchers.Main) { onUtterance(wav) }
                            _state.value = RecordingState.LISTENING
                        }
                    }
                }
            }
            _state.value = RecordingState.IDLE
        }
    }

    fun stop() {
        running = false
        recordJob?.cancel(); recordJob = null
        runCatching { record?.stop() }
        runCatching { record?.release() }
        record = null
        _level.value = 0f
        _state.value = RecordingState.IDLE
    }

    private fun appendPcm(out: ByteArrayOutputStream, buf: ShortArray, n: Int) {
        for (i in 0 until n) {
            val v = buf[i].toInt()
            out.write(v and 0xFF)
            out.write((v shr 8) and 0xFF)
        }
    }

    /** Сырой PCM16 в WAV-контейнер (Whisper ест WAV). */
    private fun pcmToWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val out = ByteArrayOutputStream()
        fun wInt(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF); out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF) }
        fun wShort(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }
        out.write("RIFF".toByteArray()); wInt(pcm.size + 36); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); wInt(16); wShort(1); wShort(1)
        wInt(sampleRate); wInt(sampleRate * 2); wShort(2); wShort(16)
        out.write("data".toByteArray()); wInt(pcm.size); out.write(pcm)
        return out.toByteArray()
    }

    fun release() { stop(); scope.cancel() }
}
